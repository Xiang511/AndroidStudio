package com.example.mssql2;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView id = (TextView) findViewById(R.id.edittexid);
        TextView name = (TextView) findViewById(R.id.edittextname);
        TextView price = (TextView) findViewById(R.id.price);
        TextView textView4 = (TextView) findViewById(R.id.textView4);


        Button btninsert = (Button) findViewById(R.id.btnadd);
        Button btnupdate = (Button) findViewById(R.id.btnupdate);
        Button btndelete = (Button) findViewById(R.id.btndelete);
        Button btnget = (Button) findViewById(R.id.btnget);

        btninsert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Connection connection = connectionclass();
                try {
                    if (connection != null) {
                        String sqlinsert = "Insert into Table1 values ('" + id.getText().toString() + "','" + name.getText().toString() + "','" + price.getText().toString() + "')";
                        Statement st = connection.createStatement();
                        ResultSet rs = st.executeQuery(sqlinsert);
                        Toast.makeText(getApplicationContext(), "新增成功", Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception exception) {
                    Log.e("Error", exception.getMessage());
                }
            }
        });

        btnupdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Connection connection = connectionclass();
                try {
                    if (connection != null) {
                        String sqlupdate = "update Table1 set id='" + id.getText().toString() + "',name='" + name.getText().toString() + "',price='" + price.getText().toString() + "' where id= '"+ id.getText().toString()+"'";
                        Statement st = connection.createStatement();
                        int rows = st.executeUpdate(sqlupdate);
                        Toast.makeText(getApplicationContext(), "更新成功", Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception exception) {
                    Log.e("Error", exception.getMessage());
                }
            }
        });

        btndelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Connection connection = connectionclass();
                try {
                    if (connection != null) {
                        String sqldelete = "delete Table1  where id= '"+ id.getText().toString()+"'";
                        Statement st = connection.createStatement();
                        int rows = st.executeUpdate(sqldelete);
                        Toast.makeText(getApplicationContext(), "刪除成功", Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception exception) {
                    Log.e("Error", exception.getMessage());
                }
            }
        });

        btnget.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Connection connection = connectionclass();
                try {
                    if (connection != null) {
                        String sqlget = "select * from Table1 where id= '"+ id.getText().toString()+"'";
                        Statement st = connection.createStatement();
                        ResultSet rs = st.executeQuery(sqlget);
                        while(rs.next()){
                            id.setText(rs.getString(1));
                            name.setText(rs.getString(2));
                            price.setText(rs.getString(3));


                        }

                    }
                } catch (Exception exception) {
                    Log.e("Error", exception.getMessage());
                }
                try {
                    if (connection != null) {
                        String sqlget = "select * from Table1 ";
                        Statement st = connection.createStatement();
                        ResultSet rs = st.executeQuery(sqlget);
                        StringBuilder sb = new StringBuilder();
                        while(rs.next()){

                                String id = rs.getString("id");

                                String name = rs.getString("name");

                                String price = rs.getString("price");
                                // 在 Logcat 中顯示取得的資料
                                sb.append(id+"     ").append(name+"     ").append(price).append("\n");

                        }textView4.setText(sb.toString());

                    }
                } catch (Exception exception) {
                    Log.e("Error", exception.getMessage());
                }
            }
        });

    }
    @SuppressLint("NewApi")
    public Connection connectionclass() {
        Connection con = null;
        String ip = "10.0.2.2", port = "1433", username = "sa", password = "123", databasename = "db1";
        StrictMode.ThreadPolicy tp = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(tp);
        try {
            Class.forName("net.sourceforge.jtds.jdbc.Driver");
            String connectionUrl = "jdbc:jtds:sqlserver://" + ip + ":" + port + ";databasename=" + databasename + ";User=" + username + ";password=" + password + ";";
            con = DriverManager.getConnection(connectionUrl);
        } catch (Exception exception) {
            Log.e("Error", exception.getMessage());
        }
        return con;
    }
}